package com.jp.physiquetracker;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(11,13,12);
    private static final int CARD = Color.rgb(21,26,23);
    private static final int LIME = Color.rgb(183,243,74);
    private static final int WHITE = Color.rgb(244,246,242);
    private static final int MUTED = Color.rgb(154,163,156);
    private LinearLayout root, content, nav;
    private android.content.SharedPreferences prefs;
    private String currentTab = "HOME";

    private final String[][] days = {
        {"MONDAY • PUSH A", "Incline dumbbell press|3 × 8–12", "Flat machine chest press|3 × 8–12", "Cable chest fly|2 × 12–15", "Cable lateral raises|4 × 12–20", "Rope triceps pushdown|3 × 10–15", "Overhead triceps extension|2 × 10–15"},
        {"TUESDAY • PULL A", "Lat pulldown|3 × 8–12", "Chest-supported row|3 × 8–12", "Single-arm cable pulldown|2 × 10–12", "Reverse pec deck|3 × 12–20", "EZ-bar curls|3 × 8–12", "Hammer curls|2 × 10–15"},
        {"WEDNESDAY • CARDIO", "Bike HIIT|30 sec hard / 90 sec easy × 6–8 rounds"},
        {"THURSDAY • UPPER A", "Incline machine chest press|3 × 8–12", "Neutral-grip lat pulldown|3 × 8–12", "Seated cable row|2 × 10–12", "Cable lateral raises|3 × 12–20", "Preacher curls|2 × 10–12", "Rope triceps pushdown|2 × 10–15"},
        {"FRIDAY • LEGS + ABS", "Squats|3 × 8–12", "Leg extensions|3 × 12–15", "Seated leg curls|2 × 10–15", "Standing calf raises|2 × 12–15", "Cable crunches|3 × 12–15", "Hanging knee raises|2 × 10–15"},
        {"SATURDAY • UPPER B", "Flat dumbbell press|3 × 8–12", "One-arm cable pulldown|3 × 10–12", "Chest-supported row|2 × 10–12", "Cable lateral raises|3 × 12–20", "Reverse pec deck|2 × 12–20", "Incline dumbbell curls|2 × 10–12", "Overhead triceps extension|2 × 10–15"},
        {"SUNDAY • CARDIO", "Incline treadmill|30 minutes", "Stationary cycling|10–15 minutes"}
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        prefs = getSharedPreferences("physique_tracker", MODE_PRIVATE);
        buildShell();
        showTab("HOME");
    }

    private void buildShell() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        setContentView(root);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setBackgroundColor(CARD);
        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(60)));
        String[] tabs = {"HOME","WORKOUT","NUTRITION","PROGRESS"};
        for (String t : tabs) {
            TextView v = new TextView(this); v.setText(t); v.setTextSize(10); v.setGravity(Gravity.CENTER);
            v.setTypeface(null, Typeface.BOLD); v.setTextColor(MUTED);
            nav.addView(v, new LinearLayout.LayoutParams(0, -1, 1));
            v.setOnClickListener(w -> showTab(t));
        }
    }

    private void showTab(String tab) {
        currentTab = tab; content.removeAllViews();
        for (int i=0;i<nav.getChildCount();i++) {
            TextView tv=(TextView)nav.getChildAt(i);
            tv.setTextColor(tv.getText().toString().equals(tab)?LIME:MUTED);
        }
        if ("HOME".equals(tab)) dashboard();
        else if ("WORKOUT".equals(tab)) workout();
        else if ("NUTRITION".equals(tab)) nutrition();
        else progress();
    }

    private void header(String eyebrow, String title) {
        TextView e = text(eyebrow, 11, LIME, true); e.setPadding(0,dp(24),0,dp(5)); content.addView(e);
        TextView t = text(title, 27, WHITE, true); content.addView(t);
        content.setPadding(dp(18),0,dp(18),dp(24));
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if(bold) v.setTypeface(null,Typeface.BOLD); return v;
    }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(15),dp(14),dp(15),dp(14));
        c.setBackground(shape(CARD,16)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(12); content.addView(c,p); return c;
    }
    private void gap(LinearLayout box,int h){ View v=new View(this); box.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    private String val(String k,String def){return prefs.getString(k,def);}
    private void save(String k,String v){prefs.edit().putString(k,v).apply();}
    private String todayKey(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
    private String dayName(){return new SimpleDateFormat("EEEE",Locale.US).format(new Date()).toUpperCase(Locale.US);}
    private int dayIndex(){Calendar c=Calendar.getInstance(); return (c.get(Calendar.DAY_OF_WEEK)+5)%7;}
    private void dashboard() {
        header("PHYSIQUE TRACKER", "Your fitness journey");
        TextView sub=text("BUILD CONSISTENCY. TRACK PROGRESS.",10,MUTED,true); content.addView(sub); gap(content,18);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); content.addView(row);
        metric(row,"BODY WEIGHT",val("weight","72"),"kg");
        metric(row,"CALORIE TARGET",val("calTarget","2200"),"kcal");
        LinearLayout p=card(); p.addView(text("DAILY PROTEIN",11,MUTED,true));
        p.addView(text(val("proteinToday","0")+" g  /  "+val("proteinTarget","130")+" g",25,LIME,true));
        p.addView(text("Log your food in Nutrition",12,MUTED,false));
        LinearLayout w=card(); w.addView(text("TODAY'S SESSION",11,LIME,true));
        int ix=dayIndex(); w.addView(text(days[ix][0],20,WHITE,true)); gap(w,5);
        w.addView(text(ix==2||ix==6?"Cardio day — keep it steady.":"Strength session — focus on controlled reps.",13,MUTED,false));
        Button b=button("OPEN TODAY'S WORKOUT"); w.addView(b); b.setOnClickListener(v->showTab("WORKOUT"));
        LinearLayout quick=card(); quick.addView(text("QUICK CHECK-IN",15,WHITE,true));
        Button bw=button("LOG BODY WEIGHT"); quick.addView(bw); bw.setOnClickListener(v->weightDialog());
        Button bn=button("LOG CALORIES & PROTEIN"); quick.addView(bn); bn.setOnClickListener(v->showTab("NUTRITION"));
    }
    private void metric(LinearLayout row,String label,String value,String unit) {
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(13),dp(13),dp(8),dp(13)); c.setBackground(shape(CARD,14));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.rightMargin=dp(6); row.addView(c,lp);
        c.addView(text(label,9,MUTED,true)); c.addView(text(value+" "+unit,21,LIME,true));
    }
    private Button button(String s) {
        Button b=new Button(this); b.setText(s); b.setTextSize(12); b.setTextColor(BG); b.setAllCaps(false); b.setTypeface(null,Typeface.BOLD);
        b.setBackground(shape(LIME,12)); return b;
    }
    private void workout() {
        header("TRAINING PLAN", "Weekly workouts");
        TextView note=text("Tap an exercise to record your working weight, reps and completion.",12,MUTED,false); content.addView(note); gap(content,14);
        for(int i=0;i<7;i++){
            final int day=i;
            LinearLayout c=card(); c.addView(text(days[i][0],15,LIME,true)); gap(c,6);
            for(int j=1;j<days[i].length;j++){
                final int ex=j; String name=days[i][j].split("\\|")[0]; String prescription=days[i][j].split("\\|")[1];
                LinearLayout line=new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
                CheckBox check=new CheckBox(this); check.setButtonTintList(android.content.res.ColorStateList.valueOf(LIME));
                String key="done_"+todayKey()+"_"+day+"_"+j; check.setChecked(prefs.getBoolean(key,false));
                TextView label=text(name+"\\n"+prescription,13,WHITE,false); line.addView(check);
                line.addView(label,new LinearLayout.LayoutParams(0,-2,1));
                c.addView(line);
                check.setOnCheckedChangeListener((v,is)->prefs.edit().putBoolean(key,is).apply());
                line.setOnClickListener(v->exerciseDialog(day,ex,name,prescription));
            }
            if(i==dayIndex()){
                Button start=button("LOG TODAY'S SESSION"); c.addView(start);
                start.setOnClickListener(v->Toast.makeText(this,"Tap an exercise to log weight and reps.",Toast.LENGTH_SHORT).show());
            }
        }
    }
    private void exerciseDialog(int day,int ex,String name,String prescription) {
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(8),dp(4),dp(8),0); box.setOrientation(LinearLayout.VERTICAL);
        EditText weight=edit("Weight used (kg)",val("exw_"+day+"_"+ex,""));
        EditText reps=edit("Reps completed",val("exr_"+day+"_"+ex,""));
        EditText sets=edit("Sets completed",val("exs_"+day+"_"+ex,""));
        box.addView(text(name+" • "+prescription,14,WHITE,true)); box.addView(weight); box.addView(reps); box.addView(sets);
        new AlertDialog.Builder(this).setTitle("Exercise log").setView(box)
            .setPositiveButton("SAVE",(d,w)->{save("exw_"+day+"_"+ex,weight.getText().toString());save("exr_"+day+"_"+ex,reps.getText().toString());save("exs_"+day+"_"+ex,sets.getText().toString());Toast.makeText(this,"Exercise log saved",Toast.LENGTH_SHORT).show();})
            .setNegativeButton("CANCEL",null).show();
    }
    private EditText edit(String hint,String value) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setText(value); e.setTextColor(WHITE); e.setHintTextColor(MUTED);
        return e;
    }
    private void nutrition() {
        header("DAILY NUTRITION", "Fuel your progress");
        LinearLayout c=card(); c.addView(text("CALORIE TARGET",11,MUTED,true)); c.addView(text(val("calTarget","2200")+" kcal",25,LIME,true));
        Button ct=button("CHANGE CALORIE TARGET"); c.addView(ct); ct.setOnClickListener(v->numberDialog("Calorie target","calTarget","2200"));
        LinearLayout p=card(); p.addView(text("PROTEIN TARGET",11,MUTED,true)); p.addView(text(val("proteinToday","0")+" g / "+val("proteinTarget","130")+" g",25,LIME,true));
        Button pt=button("CHANGE PROTEIN TARGET"); p.addView(pt); pt.setOnClickListener(v->numberDialog("Protein target","proteinTarget","130"));
        LinearLayout log=card(); log.addView(text("TODAY'S INTAKE",15,WHITE,true));
        Button add=button("ADD FOOD / MEAL"); log.addView(add); add.setOnClickListener(v->{
            LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
            EditText food=edit("Food / meal name",""); EditText kcal=edit("Calories (kcal)",""); EditText protein=edit("Protein (g)","");
            box.addView(food);box.addView(kcal);box.addView(protein);
            new AlertDialog.Builder(this).setTitle("Add nutrition entry").setView(box).setPositiveButton("SAVE",(d,x)->{
                int k=parse(kcal.getText().toString()), pr=parse(protein.getText().toString());
                int newCalories = parse(val("calToday_"+todayKey(),"0")) + k;
                int newProtein = parse(val("proteinToday_"+todayKey(),"0")) + pr;
                save("calToday_"+todayKey(),String.valueOf(newCalories));
                save("proteinToday_"+todayKey(),String.valueOf(newProtein));
                save("proteinToday",String.valueOf(newProtein));
                Toast.makeText(this,"Meal saved",Toast.LENGTH_SHORT).show(); showTab("NUTRITION");
            }).setNegativeButton("CANCEL",null).show();
        });
        log.addView(text("Calories logged today: "+val("calToday_"+todayKey(),"0")+" kcal",13,MUTED,false));
        log.addView(text("Protein logged today: "+val("proteinToday_"+todayKey(),"0")+" g",13,MUTED,false));
    }
    private int parse(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}
    private void numberDialog(String title,String key,String def) {
        EditText e=edit("Enter value",val(key,def));
        new AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("SAVE",(d,w)->{save(key,e.getText().toString());showTab(currentTab);}).setNegativeButton("CANCEL",null).show();
    }
    private void weightDialog() {
        EditText e=edit("Weight in kg",val("weight","72"));
        new AlertDialog.Builder(this).setTitle("Update body weight").setView(e).setPositiveButton("SAVE",(d,w)->{save("weight",e.getText().toString());save("weightDate",new SimpleDateFormat("dd MMM yyyy",Locale.US).format(new Date()));showTab("HOME");}).setNegativeButton("CANCEL",null).show();
    }
    private void progress() {
        header("BODY COMPOSITION", "Progress check-in");
        LinearLayout w=card(); w.addView(text("CURRENT BODY WEIGHT",11,MUTED,true)); w.addView(text(val("weight","72")+" kg",26,LIME,true));
        Button wb=button("UPDATE WEIGHT"); w.addView(wb); wb.setOnClickListener(v->weightDialog());
        LinearLayout m=card(); m.addView(text("BODY MEASUREMENTS",15,WHITE,true)); gap(m,5);
        measurement(m,"Waist (cm)","waist"); measurement(m,"Chest (cm)","chest"); measurement(m,"Arms (cm)","arms");
        LinearLayout h=card(); h.addView(text("CONSISTENCY",15,WHITE,true));
        h.addView(text("Check off exercises in the Workout tab. Your exercise logs and check-ins are saved on this phone.",13,MUTED,false));
        h.addView(text("Last weight update: "+val("weightDate","Not recorded yet"),12,LIME,false));
        h.addView(text("Starting nutrition guide: about 2,200 kcal and 130 g protein daily. Adjust based on your 2–3 week weight trend.",12,MUTED,false));
    }
    private void measurement(LinearLayout box,String label,String key) {
        LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(text(label,14,WHITE,false),new LinearLayout.LayoutParams(0,dp(48),1));
        TextView value=text(val(key,"—")+" cm",14,LIME,true); r.addView(value);
        Button edit=button("EDIT"); r.addView(edit); edit.setOnClickListener(v->{
            EditText e=edit("Measurement in cm",val(key,""));
            new AlertDialog.Builder(this).setTitle(label).setView(e).setPositiveButton("SAVE",(d,x)->{save(key,e.getText().toString());showTab("PROGRESS");}).setNegativeButton("CANCEL",null).show();
        });
        box.addView(r);
    }
}