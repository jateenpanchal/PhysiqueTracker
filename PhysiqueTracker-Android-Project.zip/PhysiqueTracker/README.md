# Physique Tracker (Android)

A native Android fitness tracker built with Java and the Android SDK.

## Features in v1.0
- Dashboard with current weight, calorie target and protein target
- Weekly workout plan (5 strength days + 2 cardio days)
- Exercise check-offs and simple set/reps/weight logging
- Daily calorie and protein entries
- Weight, waist, chest and arm check-ins
- Local offline storage using Android SharedPreferences

## Build an APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (not the enclosing folder).
3. Wait for the `Build Physique Tracker APK` workflow to finish, or run it manually from Actions.
4. Open the completed workflow run and download the `PhysiqueTracker-APK` artifact.
5. Extract the downloaded ZIP. Install `app-debug.apk` on your Android phone.

The workflow uses Java 17 and Gradle 8.13. It creates a debug APK suitable for personal testing and installation.

## Package
`com.jp.physiquetracker`

## Important
This is a first working version, not a Play Store release. The debug APK is not a signed Play Store release. Keep a backup of important data before uninstalling the app because locally stored app data can be removed by uninstalling.
