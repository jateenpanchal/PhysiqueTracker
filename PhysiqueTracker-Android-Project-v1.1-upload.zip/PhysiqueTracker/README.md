# Physique Tracker 1.1

Native Android fitness tracker (Java).

## What's included
- Redesigned dark dashboard with lime accent, gradient workout hero, metric cards and animated screen transitions.
- Weekly 5-strength / 2-cardio routine.
- Exercise completion checkboxes and weight / reps / sets logging.
- Daily calorie and protein logging and editable targets.
- Body weight and waist, chest, arm measurements.
- Local offline storage with SharedPreferences.

## Build
The GitHub Actions workflow in `.github/workflows/android.yml` builds a debug APK with Java 17 and Gradle 8.13.

## Update an existing installation
Keep applicationId `com.jp.physiquetracker`. This build is a debug build. For repeat in-place updates, configure a persistent signing key in GitHub Actions; otherwise Android may reject an APK signed with a different debug key.
