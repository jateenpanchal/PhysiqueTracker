package com.jp.physiquetracker;

import android.app.*;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(9,12,11), panel=Color.rgb(19,25,22), panel2=Color.rgb(27,34,30);
    int lime=Color.rgb(190,255,75), white=Color.rgb(245,247,242), muted=Color.rgb(145,157,148);
    LinearLayout root, body, bottom;
    SharedPreferences sp;
    String tab="HOME";
    String[] tabs={"HOME","WORKOUT","NUTRITION","PROGRESS"};
    String[][] plan={
      {"MONDAY • PUSH A","Incline dumbbell press|3 × 8–12","Flat machine chest press|3 × 8–12","Cable chest fly|2 × 12–15","Cable lateral raises|4 × 12–20","Rope triceps pushdown|3 × 10–15","Overhead triceps extension|2 × 10–15"},
      {"TUESDAY • PULL A","Lat pulldown|3 × 8–12","Chest-supported row|3 × 8–12","Single-arm cable pulldown|2 × 10–12","Reverse pec deck|3 × 12–20","EZ-bar curls|3 × 8–12","Hammer curls|2 × 10–15"},
      {"WEDNESDAY • CARDIO","Bike HIIT|30 sec hard / 90 sec easy × 6–8 rounds"},
      {"THURSDAY • UPPER A","Incline machine chest press|3 × 8–12","Neutral-grip lat pulldown|3 × 8–12","Seated cable row|2 × 10–12","Cable lateral raises|3 × 12–20","Preacher curls|2 × 10–12","Rope triceps pushdown|2 × 10–15"},
      {"FRIDAY • LEGS + ABS","Squats|3 × 8–12","Leg extensions|3 × 12–15","Seated leg curls|2 × 10–15","Standing calf raises|2 × 12–15","Cable crunches|3 × 12–15","Hanging knee raises|2 × 10–15"},
      {"SATURDAY • UPPER B","Flat dumbbell press|3 × 8–12","One-arm cable pulldown|3 × 10–12","Chest-supported row|2 × 10–12","Cable lateral raises|3 × 12–20","Reverse pec deck|2 × 12–20","Incline dumbbell curls|2 × 10–12","Overhead triceps extension|2 × 10–15"},
      {"SUNDAY • CARDIO","Incline treadmill|30 minutes","Stationary cycling|10–15 minutes"}
    };
    @Override public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("physique_tracker",0);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);getWindow().getDecorView().setSystemUiVisibility(0);shell();render("HOME");}
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable shape(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    GradientDrawable gradient(int a,int b,int r){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(dp(r));return d;}
    TextView tv(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,1);return t;}
    void shell(){
      root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(bg);setContentView(root);
      ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setClipToPadding(false);
      body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(20),dp(12),dp(20),dp(24));sc.addView(body);
      root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
      bottom=new LinearLayout(this);bottom.setOrientation(0);bottom.setGravity(Gravity.CENTER);bottom.setPadding(dp(8),dp(8),dp(8),dp(8));bottom.setBackgroundColor(Color.rgb(15,20,17));
      root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(68)));
      for(String t:tabs){LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setGravity(Gravity.CENTER);TextView ico=tv(icon(t),19,muted,true);TextView label=tv(t,9,muted,true);item.addView(ico);item.addView(label);bottom.addView(item,new LinearLayout.LayoutParams(0,-1,1));item.setOnClickListener(v->render(t));}
    }
    String icon(String t){if(t.equals("HOME"))return "⌂";if(t.equals("WORKOUT"))return "✦";if(t.equals("NUTRITION"))return "◉";return "↗";}
    void render(String t){tab=t;body.removeAllViews();for(int i=0;i<bottom.getChildCount();i++){LinearLayout it=(LinearLayout)bottom.getChildAt(i);boolean active=tabs[i].equals(t);((TextView)it.getChildAt(0)).setTextColor(active?lime:muted);((TextView)it.getChildAt(1)).setTextColor(active?lime:muted);}
      if(t.equals("HOME"))home();else if(t.equals("WORKOUT"))workout();else if(t.equals("NUTRITION"))nutrition();else progress();
      body.setAlpha(0f);body.setTranslationY(dp(8));body.animate().alpha(1f).translationY(0).setDuration(220).start();
    }
    void top(String eyebrow,String title,String sub){TextView e=tv(eyebrow.toUpperCase(Locale.US),10,lime,true);e.setLetterSpacing(.16f);e.setPadding(0,dp(18),0,dp(7));body.addView(e);TextView h=tv(title,29,white,true);body.addView(h);if(sub!=null){TextView s=tv(sub,13,muted,false);s.setPadding(0,dp(5),0,dp(16));body.addView(s);}}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(dp(16),dp(15),dp(16),dp(15));c.setBackground(shape(panel,20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(13);body.addView(c,p);return c;}
    TextView small(String s){return tv(s.toUpperCase(Locale.US),10,muted,true);}
    void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    String get(String k,String d){return sp.getString(k,d);} void put(String k,String v){sp.edit().putString(k,v).apply();}
    Button btn(String label){Button b=new Button(this);b.setText(label);b.setTextSize(12);b.setTextColor(bg);b.setAllCaps(false);b.setTypeface(null,1);b.setPadding(dp(12),0,dp(12),0);b.setBackground(gradient(lime,Color.rgb(155,221,52),14));return b;}
    void home(){
      String day= new SimpleDateFormat("EEEE",Locale.US).format(new Date()).toUpperCase(Locale.US);
      top("PHYSIQUE TRACKER  /  YOUR PERSONAL COACH","Let's get stronger.","Consistency beats intensity. Show up and do the work.");
      LinearLayout hero=new LinearLayout(this);hero.setOrientation(1);hero.setPadding(dp(18),dp(18),dp(18),dp(18));hero.setBackground(gradient(Color.rgb(49,69,37),Color.rgb(23,36,25),24));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.bottomMargin=dp(14);body.addView(hero,hp);
      TextView tag=tv("TODAY'S FOCUS",10,lime,true);tag.setLetterSpacing(.13f);hero.addView(tag);gap(hero,8);
      int ix=dayIndex();hero.addView(tv(plan[ix][0].replace(" • ","  /  "),20,white,true));gap(hero,5);
      hero.addView(tv(ix==2||ix==6?"Cardio day • build your engine":"Strength day • controlled reps, progressive overload",12,Color.rgb(206,217,199),false));gap(hero,16);
      Button go=btn("OPEN TODAY'S SESSION     →");hero.addView(go);go.setOnClickListener(v->render("WORKOUT"));
      LinearLayout metrics=new LinearLayout(this);metrics.setOrientation(0);body.addView(metrics);metric(metrics,"BODY WEIGHT",get("weight","72"),"KG");metric(metrics,"CALORIE GOAL",get("calTarget","2200"),"KCAL");
      LinearLayout p=card();p.addView(small("DAILY PROTEIN"));gap(p,5);p.addView(tv(get("proteinToday_"+dateKey(),"0")+"  /  "+get("proteinTarget","130")+" g",23,lime,true));TextView hint=tv("Protein logged today",11,muted,false);p.addView(hint);gap(p,9);bar(p,number(get("proteinToday_"+dateKey(),"0")),number(get("proteinTarget","130")));
      LinearLayout week=card();week.addView(small("YOUR WEEK"));gap(week,10);LinearLayout days=new LinearLayout(this);days.setOrientation(0);week.addView(days);String[] ds={"M","T","W","T","F","S","S"};for(int i=0;i<7;i++){LinearLayout d=new LinearLayout(this);d.setOrientation(1);d.setGravity(Gravity.CENTER);TextView circle=tv(ds[i],12,i==dayIndex()?bg:white,true);circle.setGravity(Gravity.CENTER);circle.setBackground(shape(i==dayIndex()?lime:panel2,30));d.addView(circle,new LinearLayout.LayoutParams(dp(32),dp(32)));TextView type=tv(i==2||i==6?"C":"S",9,muted,true);type.setPadding(0,dp(5),0,0);d.addView(type);days.addView(d,new LinearLayout.LayoutParams(0,-2,1));}}
    void metric(LinearLayout row,String label,String value,String unit){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(dp(13),dp(14),dp(8),dp(14));c.setBackground(shape(panel,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.rightMargin=dp(7);lp.bottomMargin=dp(13);row.addView(c,lp);c.addView(small(label));gap(c,5);c.addView(tv(value,24,lime,true));c.addView(tv(unit,9,muted,true));}
    void bar(LinearLayout parent,int value,int target){View track=new View(this);track.setBackground(shape(panel2,20));parent.addView(track,new LinearLayout.LayoutParams(-1,dp(7)));View fill=new View(this);fill.setBackground(shape(lime,20));int width=(int)(getResources().getDisplayMetrics().widthPixels*.78*Math.min(1.0,target<=0?0:(double)value/target));FrameLayout f=new FrameLayout(this);f.addView(track,new FrameLayout.LayoutParams(-1,dp(7)));f.addView(fill,new FrameLayout.LayoutParams(Math.max(dp(3),width),dp(7)));parent.removeView(track);parent.addView(f);}
    int number(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    String dateKey(){return new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date());}
    int dayIndex(){return (Calendar.getInstance().get(Calendar.DAY_OF_WEEK)+5)%7;}
    void workout(){top("TRAINING PLAN","Your workouts","Five strength sessions. Two cardio days. Built around your goal.");for(int i=0;i<7;i++){final int day=i;LinearLayout c=card();LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);c.addView(row);TextView title=tv(plan[i][0],14,lime,true);row.addView(title,new LinearLayout.LayoutParams(0,-2,1));row.addView(tv(i==2||i==6?"CARDIO":"STRENGTH",9,muted,true));gap(c,9);for(int j=1;j<plan[i].length;j++){final int ex=j;String[] parts=plan[i][j].split("\\|");LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);CheckBox check=new CheckBox(this);check.setButtonTintList(android.content.res.ColorStateList.valueOf(lime));String key="done_"+dateKey()+"_"+day+"_"+j;check.setChecked(sp.getBoolean(key,false));line.addView(check);TextView name=tv(parts[0],13,white,false);line.addView(name,new LinearLayout.LayoutParams(0,-2,1));line.addView(tv(parts[1],11,muted,false));c.addView(line);check.setOnCheckedChangeListener((v,b)->sp.edit().putBoolean(key,b).apply());line.setOnClickListener(v->exercise(day,ex,parts[0],parts[1]));}if(day==dayIndex()){gap(c,8);Button b=btn("LOG SESSION");c.addView(b);b.setOnClickListener(v->Toast.makeText(this,"Tap any exercise to log your sets.",0).show());}}}
    EditText edit(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(value);e.setTextColor(white);e.setHintTextColor(muted);return e;}
    void exercise(int day,int ex,String name,String rx){LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(8),0,dp(8),0);box.addView(tv(rx,12,lime,true));EditText w=edit("Weight used (kg)",get("exw_"+day+"_"+ex,""));EditText r=edit("Reps completed",get("exr_"+day+"_"+ex,""));EditText s=edit("Sets completed",get("exs_"+day+"_"+ex,""));box.addView(w);box.addView(r);box.addView(s);new AlertDialog.Builder(this).setTitle(name).setView(box).setPositiveButton("SAVE",(d,x)->{put("exw_"+day+"_"+ex,w.getText().toString());put("exr_"+day+"_"+ex,r.getText().toString());put("exs_"+day+"_"+ex,s.getText().toString());Toast.makeText(this,"Workout log saved",0).show();}).setNegativeButton("CANCEL",null).show();}
    void nutrition(){top("NUTRITION","Fuel your progress","A simple daily check-in to support your training.");LinearLayout target=card();target.addView(small("DAILY TARGETS"));gap(target,8);target.addView(tv(get("calTarget","2200")+" kcal",26,lime,true));target.addView(tv("Calories  •  "+get("proteinTarget","130")+" g protein",12,muted,false));Button set=btn("EDIT DAILY TARGETS");target.addView(set);set.setOnClickListener(v->targets());LinearLayout intake=card();int cal=number(get("calToday_"+dateKey(),"0")),pro=number(get("proteinToday_"+dateKey(),"0"));intake.addView(small("TODAY'S INTAKE"));gap(intake,8);intake.addView(tv(cal+" kcal",25,white,true));bar(intake,cal,number(get("calTarget","2200")));gap(intake,12);intake.addView(tv(pro+" g protein",19,lime,true));bar(intake,pro,number(get("proteinTarget","130")));Button add=btn("＋  ADD FOOD / MEAL");intake.addView(add);add.setOnClickListener(v->addMeal());}
    void targets(){LinearLayout box=new LinearLayout(this);box.setOrientation(1);EditText c=edit("Calories",get("calTarget","2200"));EditText p=edit("Protein (g)",get("proteinTarget","130"));box.addView(c);box.addView(p);new AlertDialog.Builder(this).setTitle("Daily targets").setView(box).setPositiveButton("SAVE",(d,w)->{put("calTarget",c.getText().toString());put("proteinTarget",p.getText().toString());render(tab);}).setNegativeButton("CANCEL",null).show();}
    void addMeal(){LinearLayout box=new LinearLayout(this);box.setOrientation(1);EditText food=edit("Food / meal name","");EditText k=edit("Calories (kcal)","");EditText p=edit("Protein (g)","");box.addView(food);box.addView(k);box.addView(p);new AlertDialog.Builder(this).setTitle("Add food").setView(box).setPositiveButton("SAVE",(d,w)->{put("calToday_"+dateKey(),String.valueOf(number(get("calToday_"+dateKey(),"0"))+number(k.getText().toString())));put("proteinToday_"+dateKey(),String.valueOf(number(get("proteinToday_"+dateKey(),"0"))+number(p.getText().toString())));render("NUTRITION");}).setNegativeButton("CANCEL",null).show();}
    void progress(){top("YOUR JOURNEY","Progress","Small improvements add up. Track your trend.");LinearLayout weight=card();weight.addView(small("CURRENT BODY WEIGHT"));gap(weight,6);weight.addView(tv(get("weight","72")+" kg",30,lime,true));TextView date=tv("Last updated  •  "+get("weightDate","Not recorded"),11,muted,false);weight.addView(date);Button wb=btn("UPDATE WEIGHT");weight.addView(wb);wb.setOnClickListener(v->weightDialog());LinearLayout m=card();m.addView(small("BODY MEASUREMENTS"));gap(m,7);measurement(m,"Waist","waist");measurement(m,"Chest","chest");measurement(m,"Arms","arms");}
    void weightDialog(){EditText e=edit("Weight in kg",get("weight","72"));new AlertDialog.Builder(this).setTitle("Update weight").setView(e).setPositiveButton("SAVE",(d,w)->{put("weight",e.getText().toString());put("weightDate",new SimpleDateFormat("dd MMM yyyy",Locale.US).format(new Date()));render("PROGRESS");}).setNegativeButton("CANCEL",null).show();}
    void measurement(LinearLayout c,String label,String key){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.addView(tv(label,14,white,false),new LinearLayout.LayoutParams(0,dp(48),1));r.addView(tv(get(key,"—")+" cm",13,lime,true));Button b=btn("EDIT");r.addView(b);b.setOnClickListener(v->{EditText e=edit("Measurement in cm",get(key,""));new AlertDialog.Builder(this).setTitle(label).setView(e).setPositiveButton("SAVE",(d,w)->{put(key,e.getText().toString());render("PROGRESS");}).setNegativeButton("CANCEL",null).show();});c.addView(r);}
}